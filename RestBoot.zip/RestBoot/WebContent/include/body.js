app.cp.register('customersCtrl4', function($scope, $http) {
									    $scope.buscar = function(item, event) {

							                var responsePromise = $http.get("/RestBoot/rest/sessao/usuarios");
									    	
//									    	 var responsePromise = $http.get("/RestBoot/json.txt");

							                responsePromise.success(function(data, status, headers, config) {
							                    $scope.paths = data.rows;
							                });
							                responsePromise.error(function(data, status, headers, config) {
							                    alert("AJAX failed!");
							                });
							            };

								      $scope.limpar = function() {
											    $scope.paths = null;
									  };

									  $scope.incluir = function() {
										  var  data = {
								                    senha: $scope.senhaImput,
								                    nome: $scope.nomeImput,
								                     id: $scope.idImput
								          };
										  $scope.show = data;
										  var responsePromise = $http.post("/RestBoot/rest/includeDados/incluir",data);
								     };

									  
								});