
app.cp.register('personCtrl', function($scope) {
    $scope.firstName = "John a";
    $scope.lastName = "Doe";
    $scope.fullName = function() {
        return $scope.firstName + " " + $scope.lastName;
    };
});