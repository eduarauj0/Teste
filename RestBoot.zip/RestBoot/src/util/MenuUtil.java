package util;

import java.util.ArrayList;
import java.util.List;

import fwTag.TreeDados;

public class MenuUtil {
	
	private static List<TreeDados> lista;
	private static List<TreeDados> listaFull;
	
	static{
		MenuUtil util = new MenuUtil();
		util.montaMenu();
	}
	
	private TreeDados menu;

	private void montaMenu(){
		
		MenuUtil.listaFull = dados();
		MenuUtil.lista =  carregaMenu(MenuUtil.listaFull);
	}
	
	public static TreeDados buscaMenuId(String id){
		for (TreeDados t: MenuUtil.listaFull) {
			if(t.getKey().equals(id)){
				return t;
			}
		}
		return null;
	}
	
	
	private static List<TreeDados> dados(){
//		String path = ServletActionContext.getRequest().getSession().getServletContext().getContextPath();
		//como os dados devem vir do banco
				//
				//nome q ficar� no menu
				//action da tela que ser� chamada
				//id unico
				//id do pai
				//true, se for tree componente pode ser expandable (ver tela Tree)
				List<TreeDados> listaDados = new ArrayList<TreeDados>();
				
				listaDados.add(new TreeDados("Home", "/Rest/rest/welcome/start", "1", null,"tooltip"));
				listaDados.add(new TreeDados("Home 2", "/Rest/rest/musicas/hello", "2", "1","hello"));
				listaDados.add(new TreeDados("Tabela", "/Rest/rest/xxx/pesquisa", "3", "1","tabela"));
				listaDados.add(new TreeDados("Tabela bootstrap", "/Rest/tabelaBootstrap.jsp", "4", "1","bootstrap"));
				listaDados.add(new TreeDados("Tabela angular", "/Rest/table/demo6.html", "5", "1","angular"));
				listaDados.add(new TreeDados("Inclusao", "/Rest/rest/includeDados/pesquisa", "6", "1","Inclusao"));
				listaDados.add(new TreeDados("Listar Todos Paths", "/Rest/rest/todos/pesquisa", "7", "1","lista"));
				listaDados.add(new TreeDados("Testes", "/Rest/rest/todos/pesquisa", "8", null,"lista"));
				listaDados.add(new TreeDados("Usuarios Logados", "/Rest/rest/sessao/pesquisa", "9", "8","lista"));
				
				return listaDados;
	}
	
	private List<TreeDados> carregaMenu(List<TreeDados> listaDados){
		List<TreeDados> lista = new ArrayList<TreeDados>();
		for (TreeDados dados : listaDados) {
			if(dados.getIdPai() == null || dados.getIdPai().equals("")){
				lista.add(dados);
			}else{
				getListaPos(dados.getIdPai(), lista);
				this.menu.getChildren().add(dados);
			}
		}
		return lista;
	}
	
	private void getListaPos(String id,List<TreeDados> lista){
		for (TreeDados menu : lista) {
			if(menu.getChildren()!=null && !menu.getChildren().isEmpty()){
				getListaPos(id, menu.getChildren());
			}
			
			if(menu.getKey().equals(id)){
				this.menu = menu;
			}
			
		}
	}

	public static List<TreeDados> getLista() {
		return lista;
	}

	public static void setLista(List<TreeDados> lista) {
		MenuUtil.lista = lista;
	}

	public static List<TreeDados> getListaFull() {
		return listaFull;
	}

	public static void setListaFull(List<TreeDados> listaFull) {
		MenuUtil.listaFull = listaFull;
	}
}
