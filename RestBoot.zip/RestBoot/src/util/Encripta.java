package util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
 
public class Encripta {
    public static void main(String[] args) {
        try {
//        	System.out.println(new BASE64Encoder().encode("asdf".getBytes()));
        	
        	String encriptado = encripta(" 00960750150@@1129799621176 ","10414127aaaaaaaa");
        	String desencriptado = desencripta(encriptado.getBytes(),"10414127aaaaaaaa");
        	System.out.println(desencriptado);
        	
//        	incrementa("10.41.5.5");
        } catch (Exception e) {
           e.printStackTrace();
        }
    }
    
    public static String encripta(String msg,String key){
    	try {
    		Cipher cipher = Cipher.getInstance("AES");
            byte[] mensagem = msg.getBytes();
            byte[] chave = key.getBytes();
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(chave, "AES"));
            byte[] encrypted = cipher.doFinal(mensagem);
            return new String(encrypted);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return null;
    }
    
    public static String desencripta(byte[] encriptado,String key){
    	try {
    		Cipher cipher = Cipher.getInstance("AES");
            byte[] chave = key.getBytes();
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(chave, "AES"));
            byte[] decrypted = cipher.doFinal(encriptado);
           return new String(decrypted);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return null;
    }
    
    public static String incrementa(String chave){
    	chave = chave.replaceAll("\\.", "");
    	int size = chave.length();
    	for(int i=0;i<16 - size;i++){
    		chave = chave+"a";
    	}
//    	System.out.println(chave);
    	return chave;
    }
}
