package util;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.sun.jersey.core.util.Base64;

public class Encripta2 {

	public static String chaveSimetrica = "1234567891234567";
	private static String mensagem = "essa � minha senha";
	private static SecretKey key;
	private static byte[] mensagemEncriptada;
	private static byte[] mensagemDescriptada;
	private static String tipo = "AES";
//	private static String tipo = "RSA";
	public static void main(String args[]) {
		/**
		 * Solicita ao usu�rio que informe uma chave com caracteres:
		 * (256 / 8 = 32) 32 caracteres = 256 bits
		 * (192 / 8 = 192) 24 caracteres = 192 bits
		 * (128 / 8 = 128) 16 caracteres = 128 bits
		 */
//		System.out.println("32 caracteres = chave com 256 bits"+ "\n24 caracteres = chave com 192 bits"+ "16 caracteres = chave com 128 bits"+ "\n Infomre uma Chave: ");
//		key = new SecretKeySpec(chaveSimetrica.getBytes(), "AES");
//
//		try {
//			Cipher cipher = Cipher.getInstance("AES");
//
//			cipher.init(Cipher.ENCRYPT_MODE, key);	 	 
//			/* Solicita ao usuio que informe sua mensagem a ser encriptada */	 	 
//			System.out.println("Informe sua mensagem a ser encriptada: ");	 	 
//			/* Encripta a Mensagem */	 	 
//			mensagemEncriptada = cipher.doFinal(mensagem.getBytes());	 	 
//			/* Exibe Mensagem Encriptada */	 	 
//			System.out.println(new String("Mensagem Encriptada: "	 	 
//					+ mensagemEncriptada));	 	 
//			/* Informa ao objeto a a��o de desencriptar */	 	 
//			cipher.init(Cipher.DECRYPT_MODE, key);	 	 
//			/* Recebe a mensagem encriptada e descripta */	 	 
//			mensagemDescriptada = cipher.doFinal(mensagemEncriptada);	 	 
//			/**	 	 
//			 * Converte para a base 64 e amazena a mensagem em uma variavel	 	 
//			 * auxiliar	 	 
//			 */
//			String mensagemOriginal = new String(mensagemDescriptada);	 	 
//
//			/* Exibe Mensagem Descriptada */
//			System.out.println("Mensagem Descriptada: " + mensagemOriginal);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}	 
		
		Encripta2 a2 = new Encripta2();
		String ecnriptado = a2.encripta("eu sou assim mesmo e nao adianta n�o vou mudar", chaveSimetrica);
		System.out.println(ecnriptado);
		System.out.println(a2.decripta(ecnriptado, chaveSimetrica));
		
		
		String key = "Bar12345Bar12345"; // 128 bit key
        String initVector = "RandomInitVector"; // 16 bytes IV

        System.out.println(decrypt(key, initVector,
                encrypt(key, initVector, "Hello World asdfasfasdfasfasfwr234234243423423432423434343asdfasdfsadfdsf234234asdfasdfasdafsafsdafasfdfsaffsdddffsdsd")));
	}

	public static String encripta(String msg, String key2){
		try {
			Cipher cipher = Cipher.getInstance(tipo);

			SecretKey key = new SecretKeySpec(key2.getBytes(), tipo);
			cipher.init(Cipher.ENCRYPT_MODE, key);	 	 
			byte[] mensagemEncriptada = cipher.doFinal(msg.getBytes());
			return new String(mensagemEncriptada);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";	 
	}
	
	
	public static String decripta(String msg, String key2){
		try {
			Cipher cipher = Cipher.getInstance(tipo);

			SecretKey key = new SecretKeySpec(key2.getBytes(), tipo);
			cipher.init(Cipher.DECRYPT_MODE, key);	 	 
			/* Recebe a mensagem encriptada e descripta */	 	 
			byte[] mensagemDescriptada = cipher.doFinal(msg.getBytes());	 	 
			return new String(mensagemDescriptada);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";	 
	}
	
	public static String encrypt(String key, String initVector, String value) {
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            byte[] encrypted = cipher.doFinal(value.getBytes());
            System.out.println("encrypted string: "
                    + Base64.encode(encrypted));

            return new String(Base64.encode(encrypted));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public static String decrypt(String key, String initVector, String encrypted) {
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

            byte[] original = cipher.doFinal(Base64.decode(encrypted));

            return new String(original);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }
}