package util;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.beanutils.PropertyUtils;



public class Util {

	
	public static Object clone(Object original) {
        try {
            //Increased buffer size to speed up writing
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(original);
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            return ois.readObject();
        } catch (Exception e) {
        	e.printStackTrace();
        } 
        return null;
    }
	
	public static BufferedImage imageToBufferedImage(Image im) {
	     BufferedImage bi = new BufferedImage
	        (im.getWidth(null),im.getHeight(null),BufferedImage.TYPE_INT_RGB);
	     Graphics bg = bi.getGraphics();
	     bg.drawImage(im, 0, 0, null);
	     bg.dispose();
	     return bi;
	  }
	
	public static byte[] imageToByte(Image image) throws Exception {
		BufferedImage bi = imageToBufferedImage(image);
		ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
       ImageIO.write(bi, "jpg", baos1);
       return baos1.toByteArray();
	}
	
	public static Image fileToImageCrop(File file,int x,int y,int w,int h)throws Exception {
		FileInputStream s = new FileInputStream(file);
		java.awt.Image image = ImageIO.read(s);
        java.awt.image.FilteredImageSource fis = new java.awt.image.FilteredImageSource(
            image.getSource(), new java.awt.image.CropImageFilter(x, y,w,h)
        );
        return java.awt.Toolkit.getDefaultToolkit().createImage(fis);
	}
	
	public static byte[] fileToBytesCrop(File file,int x,int y,int w,int h)throws Exception {
		FileInputStream s = new FileInputStream(file);
		java.awt.Image image = ImageIO.read(s);
        java.awt.image.FilteredImageSource fis = new java.awt.image.FilteredImageSource(
            image.getSource(), new java.awt.image.CropImageFilter(x, y,w,h)
        );
        image = java.awt.Toolkit.getDefaultToolkit().createImage(fis);
        return Util.imageToByte(image);
	}
	
	public static byte[] desenharImagem(String texto) throws IOException{
		BufferedImage bi =  new BufferedImage(60, 40,BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = bi.createGraphics();
		Font font = new Font("Comic Sans MS", Font.PLAIN, 13);
	    g2.setFont(font);
		g2.setColor(Color.WHITE);
		g2.drawString(texto, 5, 20);
		g2.setColor(Color.blue);
		g2.drawLine(10, 30, 50, 10);
		ByteArrayOutputStream baos1 = new ByteArrayOutputStream();
	    ImageIO.write(bi, "jpg", baos1);
	    return baos1.toByteArray();
	}
	
	public static String gerarCodMd5(String s1) throws NoSuchAlgorithmException{
	    MessageDigest md = MessageDigest.getInstance("MD5");
	    BigInteger hash = new BigInteger(1, md.digest(s1.getBytes()));
	    return hash.toString(16);
	}
	
	public static String gerarSHA256(String s1) throws NoSuchAlgorithmException{
	    MessageDigest md = MessageDigest.getInstance("SHA-256");
	    BigInteger hash = new BigInteger(1, md.digest(s1.getBytes()));
	    return hash.toString(16);
	}
	
	public static void main(String[] args) {
		try {
			System.out.println(gerarSHA256("admin"));
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	public static String retornaUrlServidor(HttpServletRequest request){
		return request.getRequestURL().toString().replaceAll(request.getServletPath(), "");
	}
	
	public static HashMap<String , String> getDadosHashMap(HttpServletRequest request,String nomeAtributo){
		HashMap<String , String> hash = new HashMap<String , String>();
		Enumeration<String> enu = request.getParameterNames();
		while(enu.hasMoreElements()){
			String nome = enu.nextElement();
			if(nome.startsWith(nomeAtributo)){
				int ind = nome.lastIndexOf("(");
				if(ind != -1){
					hash.put(nome.substring(ind+1, nome.length()-1), request.getParameter(nome));
				}
			}
		}
		return hash;
	}
	
	public static TreeMap getDadosHashMap(HttpServletRequest request,String nomeAtributo,Class<?> obj){
		HashMap<String , String> hash = new HashMap<String , String>();
		Enumeration<String> enu = request.getParameterNames();
		while(enu.hasMoreElements()){
			String nome = enu.nextElement();
			if(nome.startsWith(nomeAtributo)){
				int ind = nome.lastIndexOf("(");
				if(ind != -1){
					hash.put(nome.substring(ind+1, nome.length()-1), request.getParameter(nome));
				}
			}
		}
		return Util.desmontaHash(hash, obj);
	}
	
	public static TreeMap getDadosHashMap(MultivaluedMap<String, String> formParams2,String nomeAtributo,Class<?> obj){
		HashMap<String , String> hash = new HashMap<String , String>();
		
		Set<Entry<String, List<String>>> set = formParams2.entrySet();
		
		for (Entry<String, List<String>> entry : set) {
			String nome = entry.getKey();
			if(nome.startsWith(nomeAtributo)){
				int ind = nome.lastIndexOf("(");
				if(ind != -1){
					hash.put(nome.substring(ind+1, nome.length()-1), formParams2.get(nome).get(0));
				}
			}
		}
		
			
		return Util.desmontaHash(hash, obj);
	}
	
	
	
	public static void setAtributosChegada(Object objForm, HttpServletRequest request) {
		try {
			Field[] atributos = objForm.getClass().getDeclaredFields();
			for (int y = 0; y < atributos.length; y++) {
				Class<?> type = atributos[y].getType();
				if (type == String.class) {
					PropertyUtils.setProperty(objForm, atributos[y].getName(), request.getParameter(atributos[y].getName()));
				}else if(type == HashMap.class){
					PropertyUtils.setProperty(objForm, atributos[y].getName(), getDadosHashMap(request, atributos[y].getName()) );
				}else {
					PropertyUtils.setProperty(objForm, atributos[y].getName(), request.getParameterValues(atributos[y].getName()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	public static HashMap<String,String> retornaHash(HashMap hash,Class<?> obj){
		HashMap<String, String> hashString = new HashMap<String, String>();
		try {
			Set<Entry<String , Object>> ent = hash.entrySet();
			for (Entry<String, Object> entry : ent) {
				Field[] atributos = Class.forName(obj.getName()).newInstance().getClass().getDeclaredFields();
				for (int y = 0; y < atributos.length; y++) {
					hashString.put(entry.getKey()+"_"+atributos[y].getName(),(String) PropertyUtils.getProperty(entry.getValue(), atributos[y].getName()));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hashString;
	}
	
	public static TreeMap desmontaHash(HashMap<String , String> hash,Class<?> obj) {
		TreeMap<String, Object> h = new TreeMap<String, Object>();
		try {
			Set<Entry<String , String>> ent = hash.entrySet();
			for (Entry<String, String> entry : ent) {
				String[] chave = entry.getKey().split("_");
				Object t = h.get(chave[0]);
				if(t == null){
					t = Class.forName(obj.getName()).newInstance();
				}
				PropertyUtils.setProperty(t,chave[1], entry.getValue());
				h.put(chave[0], t );
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return h;
	}
	
}
