package util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;

public class OrdenadorGenerico implements Comparator<Object>{
	
	//exemplo
//	private void inicioOrdenacao(List<Usuario> lista){
//		Collections.sort(lista, new OrdenadorGenerico(new String []{"getNome","getIdade","getLocal"},true));
//	}
	
	String[] orderBy;
	boolean ascendente;
	
	public OrdenadorGenerico(String[] orderBy,boolean ascendente){
		this.orderBy = orderBy;
		this.ascendente = ascendente;
	}

	@Override
	public int compare(Object o1, Object o2) {
		try {
			for (int i=0;i<this.orderBy.length;i++) {
				String order = orderBy[i];
				int value= 0;
				if(ascendente){
					value = getPropriedade(order,o1).compareTo(getPropriedade(order,o2));
				}else{
					value = getPropriedade(order,o2).compareTo(getPropriedade(order,o1));
				}
				
				if(value != 0 || (i+1 == this.orderBy.length )){
					return value;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	private String getPropriedade(String metodo,Object obj) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException{
		Method method = obj.getClass().getMethod(metodo);
		return (String) method.invoke(obj, new Object[] {});
	}
}
