package util;

import java.util.ArrayList;
import java.util.List;

import fwTag.TreeDados;

public class MenuAngular {
	
	private static List<TreeDados> lista;
	private static List<TreeDados> listaFull;
	
	static{
		MenuAngular util = new MenuAngular();
		util.montaMenu();
	}
	
	private TreeDados menu;

	private void montaMenu(){
		
		MenuAngular.listaFull = dados();
		MenuAngular.lista =  carregaMenu(MenuAngular.listaFull);
	}
	
	public static TreeDados buscaMenuId(String id){
		for (TreeDados t: MenuAngular.listaFull) {
			if(t.getKey().equals(id)){
				return t;
			}
		}
		return null;
	}
	
	
	private static List<TreeDados> dados(){
//		String path = ServletActionContext.getRequest().getSession().getServletContext().getContextPath();
		//como os dados devem vir do banco
				//
				//nome q ficar� no menu
				//action da tela que ser� chamada
				//id unico
				//id do pai
				//true, se for tree componente pode ser expandable (ver tela Tree)
				List<TreeDados> listaDados = new ArrayList<TreeDados>();
				
				listaDados.add(new TreeDados("Grid", "#", "1", null,"tooltip"));
				listaDados.add(new TreeDados("Home 2", "#menu1", "2", "1","hello"));
				listaDados.add(new TreeDados("Tabela", "#combo", "3", "1","tabela"));
				listaDados.add(new TreeDados("Tabela bootstrap", "#eu042017", "4", "1","bootstrap"));
				listaDados.add(new TreeDados("Tabela angular", "#red", "5", "1","angular"));
				listaDados.add(new TreeDados("Inclusao", "#blue", "6", "1","Inclusao"));
				listaDados.add(new TreeDados("Listar Todos Paths", "#red", "7", "1","lista"));
				listaDados.add(new TreeDados("Testes", "#red", "8", null,"lista"));
				listaDados.add(new TreeDados("Usuarios Logados", "#red", "9", "8","lista"));
				listaDados.add(new TreeDados("Sub Usuario", "#eu042017", "10", "9","lista"));
				listaDados.add(new TreeDados("Sub Usuario 2", "#red", "11", "10","lista"));
				listaDados.add(new TreeDados("Sub Usuario 3", "#blue", "12", "9","lista"));
				listaDados.add(new TreeDados("Sub Usuario 4", "#menu1", "13", "10","lista"));
				listaDados.add(new TreeDados("Sub Usuario 5", "#eu042017", "14", "13","lista"));
				listaDados.add(new TreeDados("Sub Usuario 6", "#red", "15", "3","lista"));
				listaDados.add(new TreeDados("Body3", "#blue", "16", "1","hello"));
				
				return listaDados;
	}
	
	private List<TreeDados> carregaMenu(List<TreeDados> listaDados){
		List<TreeDados> lista = new ArrayList<TreeDados>();
		for (TreeDados dados : listaDados) {
			if(dados.getIdPai() == null || dados.getIdPai().equals("")){
				lista.add(dados);
			}else{
				getListaPos(dados.getIdPai(), lista);
				this.menu.getChildren().add(dados);
			}
		}
		return lista;
	}
	
	private void getListaPos(String id,List<TreeDados> lista){
		for (TreeDados menu : lista) {
			if(menu.getChildren()!=null && !menu.getChildren().isEmpty()){
				getListaPos(id, menu.getChildren());
			}
			
			if(menu.getKey().equals(id)){
				this.menu = menu;
			}
			
		}
	}

	public static List<TreeDados> getLista() {
		return lista;
	}

	public static void setLista(List<TreeDados> lista) {
		MenuAngular.lista = lista;
	}

	public static List<TreeDados> getListaFull() {
		return listaFull;
	}

	public static void setListaFull(List<TreeDados> listaFull) {
		MenuAngular.listaFull = listaFull;
	}
}
