package util;

import java.util.ArrayList;
import java.util.List;

import classes.RequisicaoRest;

public class ParseUrl {
	
	
	public static void main(String[] args) {
		List<RequisicaoRest> lista = new ArrayList<RequisicaoRest>();
//		lista.add(new RequisicaoRest("/sessao/usuarios","get"));
		lista.add(new RequisicaoRest("/sessao/pesquisa","get"));
		lista.add(new RequisicaoRest("/xxx/pesquisa","get"));
		lista.add(new RequisicaoRest("/menu/teste","get"));
		lista.add(new RequisicaoRest("/menu/tree","get"));
		
//		String url = "/todos/pesquisa";
//		String url = "/todos/pesquisa1";
		String url = "/sessao/usuarios";
		String metodo = "GET";
		
		System.out.println(validaPermissaoMetodo(lista, url, metodo));
	}
	
	public static boolean validaPermissaoMetodo(List<RequisicaoRest> lista,String url,String metodo){
		for (RequisicaoRest s : lista) {
//			if(split(s.getCaminho(), url)){
//				if(){
//					
//				}
//			}
			if(split(s.getCaminho(), url) && s.getMetodo().toLowerCase().equals(metodo.toLowerCase())){
//				System.out.println("tem permissao");
				return true;
			}
		}
		return false;
//		System.out.println("sem permissao");
	}
	
	private static boolean split(String caminhoOriginal,String caminho){
		String [] splitOriginal = caminhoOriginal.split("/");
		String [] split = caminho.split("/");
		
		if(splitOriginal.length != split.length){
			return false;
		}
		
		for (int i = 0; i < split.length; i++) {
			String o = splitOriginal[i];
			String s = split[i];
			
			if(o.contains("{")){
				splitOriginal[i] = split[i];
			}
			if(!split[i].equals(splitOriginal[i])){
				return false;
			}
		}
		return true;
	}
}
