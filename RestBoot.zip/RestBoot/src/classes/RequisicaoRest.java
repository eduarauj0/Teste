package classes;

public class RequisicaoRest {
	private String caminho;
	private String metodo;
	
	public RequisicaoRest(String caminho, String metodo) {
		super();
		this.caminho = caminho;
		this.metodo = metodo;
	}
	public String getCaminho() {
		return caminho;
	}
	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}
	public String getMetodo() {
		return metodo;
	}
	public void setMetodo(String metodo) {
		this.metodo = metodo;
	}
}
