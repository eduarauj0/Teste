package pack;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import util.MenuAngular;
import util.MenuUtil;
import fwTag.TreeDados;

@Path("/menu")
public class MenuResource {
	
	@Path("/teste")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public List<TreeDados> menu(@Context HttpServletRequest request) {
		return MenuUtil.getListaFull();
	}
	
	@Path("/tree")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public List<TreeDados> menuTree(@Context HttpServletRequest request) {
		return MenuUtil.getLista();
	}
	
	
	@Path("/listaMenu")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public List<TreeDados> listaMenu(@Context HttpServletRequest request) {
		return MenuAngular.getListaFull();
	}
	
	
	
}
