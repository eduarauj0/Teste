package pack;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.activation.MimetypesFileTypeMap;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.k19.models.Banda;

@Path("/musicas")
public class TesteResource {
	
    private String nome;

	static private Map<Integer, Banda> bandasMap;

	static {
		bandasMap = new HashMap<Integer, Banda>();

		Banda b1 = new Banda();
		b1.setId(1);
		b1.setNome("Led Zeppelin");
		b1.setAnoDeFormacao(1968);

		bandasMap.put(b1.getId(), b1);

		Banda b2 = new Banda();
		b2.setId(2);
		b2.setNome("AC/DC");
		b2.setAnoDeFormacao(1973);

		bandasMap.put(b2.getId(), b2);
		
		Banda b3 = new Banda();
		b3.setId(3);
		b3.setNome("AC/DC");
		b3.setAnoDeFormacao(1973);

		bandasMap.put(b3.getId(), b3);
		
		Banda b4 = new Banda();
		b4.setId(4);
		b4.setNome("ro");
		b4.setAnoDeFormacao(1973);

		bandasMap.put(b4.getId(), b4);
		
		Banda b5 = new Banda();
		b5.setId(5);
		b5.setNome("re");
		b5.setAnoDeFormacao(1973);

		bandasMap.put(b5.getId(), b5);
		
		Banda b6 = new Banda();
		b6.setId(6);
		b6.setNome("ra");
		b6.setAnoDeFormacao(1973);

		bandasMap.put(b6.getId(), b6);


	}

	@GET
	@Produces({ "text/xml", "application/json" })
	public List<Banda> getBandas() {
		return new ArrayList<Banda>(TesteResource.bandasMap.values());
	}
	

	@Path("{id}")
	@GET
//	@Produces({ "text/xml", "application/json" })
	@Produces(MediaType.APPLICATION_JSON)
	public Banda getBanda(@PathParam("id") int id) {
		return TesteResource.bandasMap.get(id);
	}
	
	@GET
	@Path("/image")
	@Produces("image/*")
	public Response getImage() {
	    File f = new File("C:\\eduardo.meta\\pc novo\\Prime2\\WebContent\\resources\\css\\imagem\\ajax.gif");

	    if (!f.exists()) {
	        throw new WebApplicationException(404);
	    }

	    String mt = new MimetypesFileTypeMap().getContentType(f);
	    return Response.ok(f, mt).build();
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}
}
