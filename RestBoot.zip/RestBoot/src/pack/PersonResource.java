package pack;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.apache.catalina.manager.util.ReverseComparator;
import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.collections.comparators.ComparableComparator;

import util.PaginatedListWrapper;
import classes.Person;

import com.google.gson.Gson;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.core.util.Base64;


@Path("/resources/persons")
public class PersonResource  {
	
	static List<Person> listaPerson = new ArrayList<Person>();
	static Long count = 0L;
    
	static{
		criar();
		criar();
		criar();
		criar();
		criar();//5
		criar();
		criar();
		criar();
		criar();
		criar();//10
		criar();
		criar();
	}
	
	static void criar(){
		Person personToSave = new Person();
        personToSave.setId(++count);
        personToSave.setName("Bob sap"+count);
        personToSave.setDescription("Piloto de f1");
        personToSave.setImageUrl("https://upload.wikimedia.org/wikipedia/commons/6/63/Moon_front-view_%28Clementine_dataset%29.png");
        listaPerson.add(personToSave);
	}

    private Integer countPersons() {
        return listaPerson.size();
    }

    @SuppressWarnings("unchecked")
    private List<Person> findPersons(int startPosition, int maxResults, String sortFields, String sortDirections) {
    	List<Person> listaPerson2 = new ArrayList<Person>();
    	if(listaPerson.size() < startPosition+maxResults){
    		BeanComparator beanComparator = new BeanComparator(sortFields);
    		BeanComparator reverseOrderBeanComparator = new BeanComparator(sortFields, new ReverseComparator(new ComparableComparator()));
    		if(sortDirections != null && sortDirections.equals("desc")){
    			Collections.sort(listaPerson, reverseOrderBeanComparator);
    		}else{
    			Collections.sort(listaPerson, beanComparator);
    		}
    		listaPerson2 = listaPerson.subList(startPosition, listaPerson.size());
    		return listaPerson2 ;
    	}else{
    		BeanComparator beanComparator = new BeanComparator(sortFields);
    		BeanComparator reverseOrderBeanComparator = new BeanComparator(sortFields, new ReverseComparator(new ComparableComparator()));
    		if(sortDirections != null && sortDirections.equals("desc")){
    			Collections.sort(listaPerson, reverseOrderBeanComparator);
    		}else{
    			Collections.sort(listaPerson, beanComparator);
    		}
    		listaPerson2 = listaPerson.subList(startPosition, startPosition+maxResults);
        	
            return listaPerson2;
    	}
    }
    

    private PaginatedListWrapper findPersons(PaginatedListWrapper wrapper) {
        wrapper.setTotalResults(countPersons());
        int start = (wrapper.getCurrentPage() - 1) * wrapper.getPageSize();
        wrapper.setList(findPersons(start,
                                    wrapper.getPageSize(),
                                    wrapper.getSortFields(),
                                    wrapper.getSortDirections()));
        return wrapper;
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String listPersons(@DefaultValue("1")
                                            @QueryParam("page")
                                            Integer page,
                                            @DefaultValue("id")
                                            @QueryParam("sortFields")
                                            String sortFields,
                                            @DefaultValue("asc")
                                            @QueryParam("sortDirections")
                                            String sortDirections) {
        PaginatedListWrapper paginatedListWrapper = new PaginatedListWrapper();
        paginatedListWrapper.setCurrentPage(page);
        paginatedListWrapper.setSortFields(sortFields);
        paginatedListWrapper.setSortDirections(sortDirections);
        paginatedListWrapper.setPageSize(10);
        //return findPersons(paginatedListWrapper);
        return new Gson().toJson(findPersons(paginatedListWrapper));
    }

    @GET
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Person getPerson(@PathParam("id") Long id) {
    	for (Person p  : listaPerson) {
			if(p.getId().intValue() == id.intValue()){
				return p;
			}
		}
        return null;
    }

    @POST
//    @Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
    public Person savePerson(Person person) {
        if (person.getId() == null) {
            Person personToSave = new Person();
            personToSave.setId(++count);
            personToSave.setName(person.getName());
            personToSave.setDescription(person.getDescription());
            personToSave.setImageUrl(person.getImageUrl());
            listaPerson.add(personToSave);
        } else {
        	Person personToUpdate = buscaPersonId(person.getId());
            personToUpdate.setName(person.getName());
            personToUpdate.setDescription(person.getDescription());
            personToUpdate.setImageUrl(person.getImageUrl());
        }

        return person;
    }
    
    public Person buscaPersonId(Long id){
    	for (Person p  : listaPerson) {
			if(p.getId().intValue() == id.intValue()){
				return p;
			}
		}
    	return null;
    }

    @DELETE
    @Path("{id}")
    public void deletePerson(@PathParam("id") Long id) {
    	for (int i=0;i<listaPerson.size();i++) {
    		Person p = listaPerson.get(i); 
			if(p.getId().intValue() == id.intValue()){
				listaPerson.remove(p);
				break;
			}
		}
    }
    
    public static final String USER_URI="http://10.41.4.127:8081/RestBoot/rest/menu/listaMenu";
	public void init() throws UnsupportedEncodingException{
		ClientConfig config = new DefaultClientConfig();
		Client client = Client.create(config);
		client.addFilter(new HTTPBasicAuthFilter("admin", "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918"));
		WebResource resource = client.resource(PersonResource.USER_URI);
		ClientResponse response = resource.type(MediaType.TEXT_HTML).get(ClientResponse.class);
		System.out.println(response);
//		System.out.println(response.getEntity(Dados.class));
		System.out.println(resource.get(String.class));
		
//		ClientResponse response2 = resource.type(MediaType.TEXT_XML).get(ClientResponse.class);
//		System.out.println(response2.getEntity(String.class));
	}
	
	 public static void main(String[] args) {
		 PersonResource r = new PersonResource();
			 try {
				 r.init();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
