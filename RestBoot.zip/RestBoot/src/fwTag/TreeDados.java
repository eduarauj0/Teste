package fwTag;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TreeDados implements Serializable {
	private String title;
	private String tooltip;
	private String key;
	private boolean isFolder;
	private String href;
	private List<TreeDados> children;
	private String idPai;
	private String icon="";
	private String addClass=null;
	private Boolean noLink=false;
	private Boolean activate=false;
	private Boolean focus= false; // Initial focused status.
	private Boolean expand= false; // Initial expanded status.
	private Boolean select= false; // Initial selected status.
	private Boolean hideCheckbox= false; // Suppress checkbox display for this node.
	private Boolean unselectable=false;
	
	public TreeDados() {
		// TODO Auto-generated constructor stub
	}
	
	
	public TreeDados(String title, String tooltip, String key,
			boolean isFolder, String href, List<TreeDados> children,
			String idPai, String icon, String addClass, Boolean noLink,
			Boolean activate, Boolean focus, Boolean expand, Boolean select,
			Boolean hideCheckbox, Boolean unselectable) {
		super();
		this.title = title;
		this.tooltip = tooltip;
		this.key = key;
		this.isFolder = isFolder;
		this.href = href;
		this.children = children;
		this.idPai = idPai;
		this.icon = icon;
		this.addClass = addClass;
		this.noLink = noLink;
		this.activate = activate;
		this.focus = focus;
		this.expand = expand;
		this.select = select;
		this.hideCheckbox = hideCheckbox;
		this.unselectable = unselectable;
	}


	public TreeDados(String title,String href,String key,String idPai,String tooltip ) {
		super();
		this.title = title;
		this.tooltip = tooltip;
		this.key = key;
		this.href = href;
		this.idPai = idPai;
		this.children = new ArrayList<TreeDados>();
	}
	
	
	public TreeDados(String title, String tooltip, String key, boolean select,
			boolean isFolder, String href) {
		super();
		this.title = title;
		this.tooltip = tooltip;
		this.key = key;
		this.select = select;
		this.isFolder = isFolder;
		this.href = href;
		this.children = new ArrayList<TreeDados>();
	}
	public TreeDados(String title, String tooltip, String key, boolean select,
			boolean isFolder, String href, List<TreeDados> children) {
		super();
		this.title = title;
		this.tooltip = tooltip;
		this.key = key;
		this.select = select;
		this.isFolder = isFolder;
		this.href = href;
		this.children = new ArrayList<TreeDados>();
	}


	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTooltip() {
		return tooltip;
	}
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public boolean getSelect() {
		return select;
	}
	public void isSelect(boolean select) {
		this.select = select;
	}
	public boolean isFolder() {
		return isFolder;
	}
	public void setFolder(boolean isFolder) {
		this.isFolder = isFolder;
	}
	public List<TreeDados> getChildren() {
		return children;
	}
	public void setChildren(List<TreeDados> children) {
		this.children = children;
	}
	public String getHref() {
		return href;
	}
	public void setHref(String href) {
		this.href = href;
	}
	public String getIdPai() {
		return idPai;
	}
	public void setIdPai(String idPai) {
		this.idPai = idPai;
	}


	public String getIcon() {
		return icon;
	}


	public void setIcon(String icon) {
		this.icon = icon;
	}


	public String getAddClass() {
		return addClass;
	}


	public void setAddClass(String addClass) {
		this.addClass = addClass;
	}


	public Boolean getNoLink() {
		return noLink;
	}


	public void setNoLink(Boolean noLink) {
		this.noLink = noLink;
	}


	public Boolean getActivate() {
		return activate;
	}


	public void setActivate(Boolean activate) {
		this.activate = activate;
	}


	public Boolean getFocus() {
		return focus;
	}


	public void setFocus(Boolean focus) {
		this.focus = focus;
	}


	public Boolean getExpand() {
		return expand;
	}


	public void setExpand(Boolean expand) {
		this.expand = expand;
	}


	public Boolean getHideCheckbox() {
		return hideCheckbox;
	}


	public void setHideCheckbox(Boolean hideCheckbox) {
		this.hideCheckbox = hideCheckbox;
	}


	public Boolean getUnselectable() {
		return unselectable;
	}


	public void setUnselectable(Boolean unselectable) {
		this.unselectable = unselectable;
	}


	public void setSelect(Boolean select) {
		this.select = select;
	}
}
