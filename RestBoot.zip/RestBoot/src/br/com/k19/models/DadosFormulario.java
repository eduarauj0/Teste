package br.com.k19.models;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DadosFormulario {
	private String name;
	private String cpf;
	private String teste[];
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String[] getTeste() {
		return teste;
	}
	public void setTeste(String[] teste) {
		this.teste = teste;
	}
}
