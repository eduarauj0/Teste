package br.com.k19.models;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Bandas {
	private String total;
	private List<Banda> result;
	
	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public List<Banda> getResult() {
		return result;
	}
	public void setResult(List<Banda> result) {
		this.result = result;
	}
}
