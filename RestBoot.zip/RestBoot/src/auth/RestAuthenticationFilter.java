package auth;

import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import util.Util;

import com.sun.jersey.api.client.ClientResponse.Status;
import com.sun.jersey.api.core.ResourceConfig;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

public class RestAuthenticationFilter implements ContainerRequestFilter{
	
	@Context
    HttpServletRequest request;

    @Context
    HttpServletResponse response;
    
    @Context
    Application application;
    
    @Context
    ResourceConfig resourceConfig;
    
    public static final String AUTHENTICATION_HEADER = "Authorization";
    
    
    
	@Override
	public ContainerRequest filter(ContainerRequest containerRequest) {
		
		String url = request.getPathInfo();
		String metodo = request.getMethod();
		

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		String authCredentials = httpServletRequest.getHeader(AUTHENTICATION_HEADER);
		
		System.out.println(request.getRequestURL());
		
		if (null == authCredentials){
			throw new WebApplicationException(Response.status(Status.UNAUTHORIZED).entity("{\"mensagem\":\"Sem Credencial!\"}").build());
		}
			
		AuthenticationService service = new AuthenticationService();
		Boolean auth = service.authenticate(authCredentials);
		
		if(!auth){
			throw new WebApplicationException(Response.status(Status.UNAUTHORIZED).entity("{\"mensagem\":\"Login errado!\"}").build());
		}
		
		Boolean expirado = service.authenticateExpirado(authCredentials);
		if(expirado){
			throw new WebApplicationException(Response.status(Status.UNAUTHORIZED).entity("{\"mensagem\":\"Login expirado!\"}").build());
		}
		
		
		return containerRequest;
	}

	private String criaHashRetorno(String login,String senha){
		try {
			return Util.gerarSHA256(login+senha+new Date().getTime()+"");
		} catch (Exception e) {
			// TODO: handle exception
		}
		return "";
	}
	
	private void setaCookie(String token){
		Cookie cookie = new Cookie("idLogHash",token);
		cookie.setMaxAge(30*60);
		cookie.setPath("/RestBoot");
		response.addCookie(cookie);
	}
	
	private String buscaCokie(String name){
		Cookie[] cookies = request.getCookies();

		if(cookies != null){
			for(Cookie cookie : cookies){
			    if(name.equals(cookie.getName())){
			        return cookie.getValue();
			    }
			}
		}
		
		return null;
	}
	
	private void mostraHeader(){
		Enumeration names = request.getHeaderNames();
	    while (names.hasMoreElements()) {
	      String name = (String) names.nextElement();
	      Enumeration values = request.getHeaders(name); // support multiple values
	      if (values != null) {
	        while (values.hasMoreElements()) {
	          String value = (String) values.nextElement();
	          System.out.println(name + ": " + value);
	        }
	      }
	    }
	}
	
	public static String retornaUrlServidor(HttpServletRequest request){
		return request.getRequestURL().toString().replaceAll(request.getPathInfo(), "");
	}
	

}
