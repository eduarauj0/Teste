package auth;

import java.io.IOException;
import java.util.Date;
import java.util.StringTokenizer;

import com.sun.jersey.core.util.Base64;

public class AuthenticationService {
	
	public boolean authenticateExpirado(String authCredentials) {

		if (null == authCredentials)
			return false;
		// header value format will be "Basic encodedstring" for Basic
		// authentication. Example "Basic YWRtaW46YWRtaW4="
		final String encodedUserPassword = authCredentials.replaceFirst("Basic"
				+ " ", "");
		String usernameAndPassword = null;
		try {
			byte[] decodedBytes = Base64.decode(encodedUserPassword);
			usernameAndPassword = new String(decodedBytes, "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
		final StringTokenizer tokenizer = new StringTokenizer(usernameAndPassword, ":");
		String username = "";
		String password = "";
		String date = "";
		boolean expirado = true;
		try {
			username = tokenizer.nextToken();
			password = tokenizer.nextToken();
			date = tokenizer.nextToken();
			System.out.println(date);
			Date d = new Date();
			d.setTime(new Long(date));
			expirado = d.getTime() <= new Date().getTime();
		} catch (Exception e) {
			System.out.println("Sem Data Login");
			expirado = true;
		}
		
		return expirado;
	}
	
	public boolean authenticate(String authCredentials) {

		if (null == authCredentials)
			return false;
		// header value format will be "Basic encodedstring" for Basic
		// authentication. Example "Basic YWRtaW46YWRtaW4="
		final String encodedUserPassword = authCredentials.replaceFirst("Basic"
				+ " ", "");
		String usernameAndPassword = null;
		try {
			byte[] decodedBytes = Base64.decode(encodedUserPassword);
			usernameAndPassword = new String(decodedBytes, "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
		final StringTokenizer tokenizer = new StringTokenizer(usernameAndPassword, ":");
		final String username = tokenizer.nextToken();
		final String password = tokenizer.nextToken();
//		final String date = tokenizer.nextToken();
		
		// we have fixed the userid and password as admin
		// call some UserService/LDAP here
		boolean authenticationStatus = "admin".equals(username)
				&& "8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918".equals(password);
		return authenticationStatus;
	}
}
